from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.mount("/", StaticFiles(directory="static", html=True), name="static")

@app.post("/api/programs")
def add_program(data: dict): return data

@app.post("/api/courses")
def add_course(data: dict): return data

@app.post("/api/assessments")
def add_assessment(data: dict): return data
